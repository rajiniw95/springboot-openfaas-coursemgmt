destination_ssh='cc@129.114.109.232'

source_sl_path='serverlessFuncs/'
source_sl_registry_path='serverlessFuncs-localRegistry/' 
destination_path='/home/cc/'

source_db_dump='/home/cc/springboot-openfaas-coursemgmt/mysql_dump/'
source_sql_k8s_yaml='mysql-k8s/'

bundled_folder='bundled-transfers/'

latency_file_name='latency-sept17-tacc.txt'

database_name='coursedb'

source_db_file_path='/var/lib/docker/overlay2/f3cd27bd4d5d97ff5ca80cf31875c362be0b0f9d8bc6b3476b984e01922d4c9d/merged/mnt/'
source_db_folder_name='data/'
source_db_complete_file_path='/var/lib/docker/overlay2/f3cd27bd4d5d97ff5ca80cf31875c362be0b0f9d8bc6b3476b984e01922d4c9d/merged/mnt/data'
destination_db_file_path='/var/lib/docker/overlay2/4215202e1182140c52d2fa911d95ec6558b45ea2315518e98408908797c241ef/merged/mnt/'

destination_pem_path='/home/cc/portable-sl-tacc.pem'
