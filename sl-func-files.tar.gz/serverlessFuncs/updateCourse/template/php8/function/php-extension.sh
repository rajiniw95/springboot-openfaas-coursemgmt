#!/bin/sh

echo "Installing PHP extensions"

# Add your extensions here, you can find a valid example in php-extension.example.sh
#
# See the template documentation for instructions on installing extensions;
# - https://github.com/openfaas/templates/tree/master/template/php8
#
# You can also install any apk packages here
